#!/usr/bin/env node
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { constants } from 'node:fs';
import { open, readFile, readdir, realpath } from 'node:fs/promises';
import {
  assert,
  parseData,
  serializeData,
  MAX_DATA_BYTES,
  VERSION,
} from './core/contracts.ts';
import { createProposal, unwrapPlan } from './core/plan.ts';
import {
  applyPlan,
  getStatus,
  readStatusMetadata,
  atomicWrite,
} from './core/apply.ts';
import type { Source } from './core/types.ts';
import { safePath, validateRelativePath } from './core/paths.ts';
import {
  HARNESS_PROFILES,
  getHarnessProfile,
  isHarnessId,
} from './agents/profiles.ts';

function parseArgs(argv: string[]) {
  const [command = 'help', ...args] = argv;
  const options: Record<string, string | true> = {};
  for (let i = 0; i < args.length; i++) {
    assert(
      args[i].startsWith('--'),
      'invalid-arguments',
      'Options must use --name value.',
    );
    const name = args[i].slice(2);
    assert(!(name in options), 'invalid-arguments', 'Duplicate option.');
    options[name] =
      args[i + 1] !== undefined && !args[i + 1].startsWith('--')
        ? args[++i]
        : true;
  }
  return { command, options };
}

async function readRegularFile(filename: string, kind = 'Input') {
  const handle = await open(
    filename,
    constants.O_RDONLY | (constants.O_NONBLOCK ?? 0),
  );
  try {
    const info = await handle.stat();
    assert(
      info.isFile(),
      'invalid-input-file',
      `${kind} must be a regular file.`,
    );
    assert(info.size <= MAX_DATA_BYTES, 'invalid-data', 'Input is too large.');
    const chunks: Buffer[] = [];
    const buffer = Buffer.alloc(64 * 1024);
    let size = 0;
    while (true) {
      const { bytesRead } = await handle.read(
        buffer,
        0,
        Math.min(buffer.length, MAX_DATA_BYTES - size + 1),
        null,
      );
      if (!bytesRead) break;
      size += bytesRead;
      assert(size <= MAX_DATA_BYTES, 'invalid-data', 'Input is too large.');
      chunks.push(Buffer.from(buffer.subarray(0, bytesRead)));
    }
    return Buffer.concat(chunks, size).toString('utf8');
  } finally {
    await handle.close();
  }
}

async function inputData(filename: unknown) {
  assert(
    typeof filename === 'string',
    'invalid-arguments',
    'Provide --input FILE or --input - for stdin.',
  );
  const text =
    filename === '-'
      ? await new Promise<string>((resolve, reject) => {
          let text = '';
          process.stdin.setEncoding('utf8');
          process.stdin.on('data', (chunk) => {
            text += chunk;
            if (text.length > 8 * 1024 * 1024) {
              reject(
                Object.assign(new Error('Input too large.'), {
                  code: 'invalid-data',
                }),
              );
              process.stdin.destroy();
            }
          });
          process.stdin.on('end', () => resolve(text));
          process.stdin.on('error', reject);
        })
      : await readRegularFile(filename);
  return parseData(text);
}

function inspectionPaths(input: unknown): string[] {
  if (input === undefined) return [];
  assert(
    typeof input === 'string' && Buffer.byteLength(input) <= 64 * 1024,
    'invalid-inspection-scope',
    'Provide a literal JSON array of forbidden paths, at most 64KiB.',
  );
  const paths = parseData(input);
  assert(
    Array.isArray(paths) && paths.length <= 128,
    'invalid-inspection-scope',
    'Provide at most 128 forbidden relative paths.',
  );
  const normalized = paths.map((item) => {
    assert(
      typeof item === 'string' &&
        item.length <= 4096 &&
        !/[\p{C}\u2028\u2029]/u.test(item),
      'invalid-inspection-scope',
      'Forbidden paths must be printable relative paths of at most 4096 characters.',
    );
    return validateRelativePath(item.replace(/\/$/, ''));
  });
  assert(
    !normalized.some((item) =>
      ['.tibicen/manifest.yml', '.tibicen/state/session.json'].some(
        (internal) => internal === item || internal.startsWith(`${item}/`),
      ),
    ),
    'forbidden-path',
    'Inspection requires the disclosed Tibicen manifest and recovery metadata; leave the forbidden scope unread.',
  );
  return [...new Set(normalized)];
}

const inspectionScope = (
  current: Pick<Awaited<ReturnType<typeof getStatus>>, 'state'>,
  requested: string[],
) => [
  ...new Set([...(current.state?.proposal.forbiddenPaths ?? []), ...requested]),
];

async function inspectCurrent(
  root: string,
  current: Awaited<ReturnType<typeof getStatus>>,
  requestedForbiddenPaths: string[] = [],
) {
  const { scanProject } = await import('./scan/index.ts');
  const { verifyInfrastructure } = await import('./verify/index.ts');
  const memory = current.state?.proposal.memory ?? current.manifest?.memory;
  const forbiddenPaths = inspectionScope(current, requestedForbiddenPaths);
  const scan = await scanProject(root, { forbiddenPaths, memory });
  const infrastructure = await verifyInfrastructure(root, {
    forbiddenPaths,
    memory,
    observedFiles: scan.files,
    components: current.state?.proposal.components,
    expectedFiles: current.state ? current.observedApplied : [],
    sharedRules:
      current.state?.proposal.sharedRules ??
      current.manifest?.sharedRules ??
      [],
    process: current.state?.proposal.process ?? current.manifest?.process,
  });
  const conflicts =
    current.recovery?.files.filter(
      (file) => file.path === memory?.path && file.state === 'ambiguous',
    ) ?? [];
  if (conflicts.length) {
    infrastructure.status = 'issues-found';
    infrastructure.issues = [
      ...(infrastructure.issues ?? []),
      ...conflicts.map((file) => ({
        path: file.path,
        reason: 'pending-memory-conflict',
      })),
    ];
  }
  return { scan, infrastructure };
}

export async function main(argv = process.argv.slice(2)) {
  const { command, options } = parseArgs(argv);
  const accepted: Record<string, string[]> = {
    scan: ['forbidden-paths'],
    discover: ['query', 'kind'],
    'source-check': ['input'],
    practices: ['agents', 'input'],
    harnesses: ['agents'],
    proposal: ['input'],
    apply: ['plan', 'approve'],
    resume: ['plan', 'approve'],
    status: ['forbidden-paths'],
    verify: ['forbidden-paths'],
    report: ['input', 'save', 'requested', 'forbidden-paths'],
    'mcp-diagnose': ['input', 'forbidden-paths'],
    'mcp-verify': ['agent', 'config', 'input', 'forbidden-paths'],
    'preset-load': ['name'],
    'preset-save': ['input', 'requested'],
    'self-test': [],
    version: [],
    help: [],
    '--help': [],
    '-h': [],
  };
  if (accepted[command])
    for (const key of Object.keys(options))
      assert(
        key === 'root' || accepted[command].includes(key),
        'invalid-arguments',
        `Unsupported option --${key}.`,
      );
  const forbiddenPaths = inspectionPaths(options['forbidden-paths']);
  const root = path.resolve(
    typeof options.root === 'string' ? options.root : process.cwd(),
  );
  if (['help', '--help', '-h'].includes(command))
    return {
      version: VERSION,
      commands: {
        scan: 'scan --root PATH [--forbidden-paths JSON_ARRAY]',
        discover: 'discover --query TEXT [--kind skill|mcp]',
        'source-check': 'source-check --input FILE_OR_STDIN_DASH',
        practices: 'practices --agents ID[,ID...] [--input FILE_OR_STDIN_DASH]',
        harnesses: 'harnesses [--agents ID[,ID...]]',
        proposal: 'proposal --root PATH --input FILE_OR_STDIN_DASH',
        apply: 'apply --root PATH --plan FILE_OR_STDIN_DASH --approve DIGEST',
        resume:
          'resume --root PATH [--plan FILE_OR_STDIN_DASH] --approve DIGEST',
        status: 'status --root PATH [--forbidden-paths JSON_ARRAY]',
        verify: 'verify --root PATH [--forbidden-paths JSON_ARRAY]',
        report:
          'report --root PATH [--input FILE_OR_STDIN_DASH] [--forbidden-paths JSON_ARRAY] [--save --requested]',
        'mcp-diagnose':
          'mcp-diagnose --root PATH --input FILE_OR_STDIN_DASH [--forbidden-paths JSON_ARRAY]',
        'mcp-verify':
          'mcp-verify --root PATH --agent claude-code|cursor|codex [--config CODEX_CONFIG --input SERVER_SPEC] [--forbidden-paths JSON_ARRAY (project-local agents only)]',
        'preset-load': 'preset-load --name NAME_OR_PATH',
        'preset-save': 'preset-save --input FILE_OR_STDIN_DASH --requested',
        'self-test': 'self-test',
        version: 'version',
      },
      consent:
        'Review the exact proposal and obtain explicit user consent before apply/resume. Autopilot is not approval.',
    };
  if (command === 'version') return { version: VERSION, schema: 1 };
  if (command === 'harnesses') {
    assert(
      options.agents === undefined || typeof options.agents === 'string',
      'invalid-agents',
      'Provide comma-separated harness IDs.',
    );
    const selected =
      options.agents === undefined
        ? HARNESS_PROFILES.map((profile) => profile.id)
        : options.agents.split(',');
    assert(
      selected.length <= 16 && selected.every(isHarnessId),
      'invalid-agents',
      'Select at most sixteen lowercase harness IDs of at most 64 characters.',
    );
    return {
      schema: 1,
      harnesses: [...new Set(selected)].map(
        (id) =>
          getHarnessProfile(id) ?? {
            id,
            status: 'unknown',
            reason: 'unsupported-agent',
          },
      ),
    };
  }
  if (command === 'scan') {
    const { scanProject } = await import('./scan/index.ts');
    const current = await readStatusMetadata(root, { forbiddenPaths });
    return scanProject(root, {
      forbiddenPaths: inspectionScope(current, forbiddenPaths),
    });
  }
  if (command === 'proposal')
    return createProposal(root, await inputData(options.input));
  if (command === 'status') {
    const result = await getStatus(root, { forbiddenPaths });
    const memory = result.state?.proposal.memory ?? result.manifest?.memory;
    return {
      schema: 1,
      ...(memory ? { memory } : {}),
      status: result.status,
      continuationAvailable: Boolean(result.state),
      sessionId:
        result.state?.id ?? result.manifest?.sessions?.at(-1)?.id ?? null,
      applied: result.observedApplied.map(({ path, action }) => ({
        path,
        action,
      })),
      recovery: result.recovery,
      commandAttempts:
        result.state?.commandAttempts ??
        result.manifest?.sessions?.at(-1)?.commandAttempts ??
        [],
      checks: result.state?.checks ?? result.manifest?.checks ?? {},
    };
  }
  if (command === 'report') {
    const { summarizeDiagnosis, validateTaskContext } =
      await import('./core/diagnosis.ts');
    const context =
      options.input === undefined
        ? undefined
        : validateTaskContext(await inputData(options.input));
    const current = await getStatus(root, { forbiddenPaths });
    const session = current.state ?? current.manifest?.sessions?.at(-1);
    const process =
      current.state?.proposal.process ?? current.manifest?.process;
    const memory = current.state?.proposal.memory ?? current.manifest?.memory;
    const { scan, infrastructure } = await inspectCurrent(
      root,
      current,
      forbiddenPaths,
    );
    const report = {
      schema: 1,
      ...(memory ? { memory } : {}),
      status: current.status,
      reason:
        current.state?.reason ?? session?.attempts?.at(-1)?.reason ?? null,
      applied: current.observedApplied.map(({ path, action }) => ({
        path,
        action,
      })),
      recovery: current.recovery,
      ...(process ? { process } : {}),
      assumptions:
        current.state?.proposal.assumptions ??
        current.manifest?.assumptions ??
        [],
      commandAttempts:
        current.state?.commandAttempts ??
        current.manifest?.sessions?.at(-1)?.commandAttempts ??
        [],
      checks: current.state?.checks ?? current.manifest?.checks ?? {},
      manualActions:
        current.state?.proposal?.manualActions ??
        current.manifest?.sessions?.at(-1)?.manualActions ??
        [],
      manualFragments:
        current.state?.proposal?.manualFragments ??
        current.manifest?.manualFragments ??
        [],
      diagnosis: summarizeDiagnosis({
        scan,
        infrastructure,
        context,
        forbiddenPaths: inspectionScope(current, forbiddenPaths),
        registeredMemoryPath: memory?.path,
        session: session?.id
          ? { id: session.id, status: current.status }
          : null,
        continuationAvailable: Boolean(current.state),
      }),
    };
    if (options.save) {
      assert(
        options.requested === true,
        'consent-required',
        'Save a report file only after an explicit user request.',
      );
      await safePath(root, '.tibicen/report.md', {
        forbiddenPaths: inspectionScope(current, forbiddenPaths),
      });
      await atomicWrite(
        root,
        '.tibicen/report.md',
        `# Tibicen\n\n\`\`\`json\n${serializeData(report)}\`\`\`\n`,
      );
      return { ...report, saved: '.tibicen/report.md' };
    }
    return report;
  }
  if (command === 'apply' || command === 'resume') {
    const plan = options.plan
      ? unwrapPlan(await inputData(options.plan))
      : (await getStatus(root)).state?.proposal;
    assert(
      plan,
      'plan-required',
      'A proposal is required. If state is absent, scan and make a new proposal.',
    );
    const { runtimeHooks } = await import('./core/runtime.ts');
    const hooks = runtimeHooks(
      root,
      plan,
      typeof options.approve === 'string' ? options.approve : '',
    );
    try {
      return await applyPlan(root, plan, {
        approvedDigest:
          typeof options.approve === 'string' ? options.approve : undefined,
        resume: command === 'resume',
        beforeApply: hooks.beforeApply,
        verify: hooks.verify,
      });
    } finally {
      await hooks.cleanup();
    }
  }
  if (command === 'verify') {
    const current = await getStatus(root, { forbiddenPaths });
    return (await inspectCurrent(root, current, forbiddenPaths)).infrastructure;
  }
  if (command === 'source-check') {
    const { validateSources } = await import('./discovery/index.ts');
    const { loadBlocklist } = await import('./core/policy.ts');
    return validateSources((await inputData(options.input)) as Source[], {
      blocklist: await loadBlocklist(),
    });
  }
  if (command === 'discover') {
    assert(
      typeof options.query === 'string',
      'invalid-arguments',
      'Provide --query TEXT.',
    );
    const { searchCandidates } = await import('./discovery/index.ts');
    const { loadBlocklist } = await import('./core/policy.ts');
    return searchCandidates(options.query, {
      kind: typeof options.kind === 'string' ? options.kind : 'skill',
      blocklist: await loadBlocklist(),
    });
  }
  if (command === 'practices') {
    const { checkPractices } = await import('./discovery/practices.ts');
    assert(
      typeof options.agents === 'string',
      'invalid-arguments',
      'Provide --agents ID[,ID...]; use harnesses to inspect known profiles.',
    );
    const input =
      options.input === undefined ? {} : await inputData(options.input);
    assert(
      input !== null &&
        typeof input === 'object' &&
        !Array.isArray(input) &&
        Object.keys(input).every((key) => key === 'agentVersions'),
      'invalid-practices-input',
      'Practice input accepts only an optional agentVersions object.',
    );
    return checkPractices({
      agents: options.agents.split(','),
      agentVersions: (input as { agentVersions?: unknown }).agentVersions,
    });
  }
  if (command === 'mcp-diagnose') {
    const { validateMcpDiagnosisRequest, diagnoseMcp } =
      await import('./mcp/diagnosis.ts');
    const request = validateMcpDiagnosisRequest(await inputData(options.input));
    const current = await getStatus(root, { forbiddenPaths });
    const { readProjectFile } = await import('./scan/index.ts');
    const configs = new Map<string, string>();
    for (const source of request.sources) {
      try {
        const { content } = await readProjectFile(root, source.path, {
          forbiddenPaths: inspectionScope(current, forbiddenPaths),
          maxFileBytes: 1024 * 1024,
        });
        configs.set(source.path, content.toString('utf8'));
      } catch {
        // Missing map entries preserve unreadable/excluded status without raw errors.
      }
    }
    return diagnoseMcp(request, configs);
  }
  if (command === 'mcp-verify') {
    const { validateMcpConfig, verifyCodexMcpBlock } =
      await import('./mcp/index.ts');
    if (options.agent === 'codex') {
      assert(
        options['forbidden-paths'] === undefined,
        'invalid-arguments',
        'Project read exclusions do not scope an explicitly selected global Codex config.',
      );
      assert(
        typeof options.config === 'string',
        'invalid-arguments',
        'Provide the explicitly selected Codex config path.',
      );
      return verifyCodexMcpBlock(
        await readRegularFile(options.config as string, 'Config'),
        await inputData(options.input),
      );
    }
    const target =
      options.agent === 'claude-code'
        ? '.mcp.json'
        : options.agent === 'cursor'
          ? '.cursor/mcp.json'
          : null;
    assert(target, 'invalid-arguments', 'Select claude-code, cursor or codex.');
    const current = await getStatus(root, { forbiddenPaths });
    const { readProjectFile } = await import('./scan/index.ts');
    const { content } = await readProjectFile(root, target, {
      forbiddenPaths: inspectionScope(current, forbiddenPaths),
      maxFileBytes: 1024 * 1024,
    });
    return validateMcpConfig(options.agent as string, content.toString('utf8'));
  }
  if (command === 'preset-load' || command === 'preset-save') {
    const { loadPreset, savePreset } = await import('./presets/index.ts');
    return command === 'preset-load'
      ? loadPreset(typeof options.name === 'string' ? options.name : '')
      : savePreset(await inputData(options.input), {
          requested: options.requested === true,
        });
  }
  if (command === 'self-test') {
    const skillRoot = path.resolve(
      path.dirname(fileURLToPath(import.meta.url)),
      '..',
    );
    const scripts = await readdir(path.join(skillRoot, 'scripts'));
    for (const stage of [
      'scan',
      'inventory',
      'interview',
      'product-arch',
      'agent-arch',
      'proposal',
      'build',
      'verify',
      'handoff',
    ]) {
      const text = await readFile(
        path.join(skillRoot, 'references', `stage-${stage}.md`),
        'utf8',
      );
      assert(text.trim(), 'missing-stage', 'Required stage resource is empty.');
    }
    return {
      schema: 1,
      status: 'passed',
      version: VERSION,
      resources: scripts.includes('tibicen.ts') ? 'available' : 'missing',
      scope: 'distribution-resource-check',
    };
  }
  assert(
    false,
    'unknown-command',
    'Unknown command. Run help for available commands.',
  );
}

if (
  process.argv[1] &&
  (await realpath(process.argv[1]).catch(() => '')) ===
    fileURLToPath(import.meta.url)
) {
  main()
    .then((result) => {
      process.stdout.write(serializeData(result));
      if (
        result &&
        'status' in result &&
        (result.status === 'incomplete' || result.status === 'issues-found')
      )
        process.exitCode = 1;
    })
    .catch((error) => {
      process.stdout.write(
        serializeData({
          schema: 1,
          error: {
            code: error.code ?? 'internal-error',
            message: error.code
              ? error.message
              : 'Operation could not complete; no successful result is claimed.',
          },
        }),
      );
      process.exitCode = 1;
    });
}
